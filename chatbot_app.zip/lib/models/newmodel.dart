// import 'package:get/get_state_manager/src/simple/get_controllers.dart';

// import '../screens/home_screen.dart';

// class UserController extends GetxController {
//   var user = UserModel();

//   void addUser(UserModel data) {
//     user = data;

//     ////print(user.userName);

//     update();
//   }}
