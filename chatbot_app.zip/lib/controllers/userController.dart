// import 'package:get/get.dart';

// import '../models/user_model.dart';

// class UserController extends GetxController {
//   var user = UserModel();

//   void addUser(UserModel data) {
//     user = data;
//     //////print(user.userName);
//     update();
//   }

//   void editUser(UserModel data) {
//     user = data;
//     update();
//   }
// }
